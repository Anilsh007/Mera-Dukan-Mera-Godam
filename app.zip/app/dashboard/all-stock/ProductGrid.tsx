"use client"

import { useState, useMemo } from "react"
import ProductCard from "./ProductCard"
import { Product } from "@/app/lib/db"
import { useRouter } from "next/navigation"
import Button from "@/app/components/utility/Button"
import { Search, X, LayoutGrid, List, ChevronDown, ChevronRight } from "lucide-react"

function expiryInfo(expiry?: string): { label: string; cls: string } | null {
    if (!expiry) return null
    const days = Math.ceil((new Date(expiry).getTime() - Date.now()) / 86400000)
    if (days < 0) return { label: "Expired", cls: "text-red-500" }
    if (days <= 7) return { label: `${days}d left`, cls: "text-red-500" }
    if (days <= 30) return { label: `${days}d left`, cls: "text-amber-500" }
    return { label: `${days}d`, cls: "text-[var(--text-muted)]" }
}

function GroupedView({ products, onSelect }: { products: Product[]; onSelect: (p: Product) => void }) {
    const grouped = useMemo(() => {
        const map = new Map<string, Map<string, Product[]>>()
        for (const p of products) {
            const cat = p.category || "Uncategorized"
            if (!map.has(cat)) map.set(cat, new Map())
            const catMap = map.get(cat)!
            if (!catMap.has(p.name)) catMap.set(p.name, [])
            catMap.get(p.name)!.push(p)
        }
        return map
    }, [products])

    const [openCats, setOpenCats] = useState<Set<string>>(() => new Set(grouped.keys()))
    const [openProducts, setOpenProducts] = useState<Set<string>>(new Set())

    const toggleCat = (cat: string) => setOpenCats(prev => { const n = new Set(prev); n.has(cat) ? n.delete(cat) : n.add(cat); return n })
    const toggleProduct = (key: string) => setOpenProducts(prev => { const n = new Set(prev); n.has(key) ? n.delete(key) : n.add(key); return n })

    return (
        <div className="space-y-3">
            {[...grouped.entries()].map(([cat, nameMap]) => {
                const catOpen = openCats.has(cat)
                const totalQty = [...nameMap.values()].flat().reduce((s, p) => s + p.quantity, 0)
                const totalValue = [...nameMap.values()].flat().reduce((s, p) => s + p.price * p.quantity, 0)

                return (
                    <div key={cat} className="rounded-2xl border border-[var(--border-card)] bg-[var(--bg-card)] overflow-hidden shadow-[var(--shadow-card)]">
                        <button onClick={() => toggleCat(cat)} className="w-full flex items-center justify-between px-5 py-4 hover:bg-[var(--bg-primary)] transition-colors">
                            <div className="flex items-center gap-3">
                                {catOpen ? <ChevronDown size={18} className="text-emerald-500" /> : <ChevronRight size={18} className="text-[var(--text-muted)]" />}
                                <span className="font-bold text-base text-[var(--text-primary)] capitalize">{cat}</span>
                                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400 font-medium">
                                    {nameMap.size} product{nameMap.size > 1 ? "s" : ""}
                                </span>
                            </div>
                            <div className="hidden sm:flex items-center gap-4 text-xs text-[var(--text-muted)]">
                                <span>Qty: <b className="text-[var(--text-primary)]">{totalQty}</b></span>
                                <span>Value: <b className="text-emerald-600">₹{totalValue.toLocaleString("en-IN")}</b></span>
                            </div>
                        </button>

                        {catOpen && (
                            <div className="divide-y divide-[var(--border-card)]">
                                {[...nameMap.entries()].map(([productName, variants]) => {
                                    const pKey = `${cat}__${productName}`
                                    const isMulti = variants.length > 1
                                    const isOpen = openProducts.has(pKey)

                                    if (!isMulti) {
                                        const p = variants[0]
                                        const exp = expiryInfo(p.expiry)
                                        return (
                                            <div key={pKey} onClick={() => onSelect(p)} className="flex items-center gap-3 px-5 py-3 hover:bg-[var(--bg-primary)] cursor-pointer transition-colors group">
                                                <div className="w-2 h-2 rounded-full bg-emerald-400 flex-shrink-0" />
                                                <span className="flex-1 text-sm font-medium text-[var(--text-primary)] group-hover:text-emerald-600 capitalize">{p.name}</span>
                                                {p.sku && <span className="text-xs text-[var(--text-muted)] hidden sm:block">SKU: {p.sku}</span>}
                                                <span className="text-sm font-semibold text-[var(--text-primary)]">₹{p.price.toLocaleString("en-IN")}</span>
                                                <span className="text-xs px-2 py-0.5 rounded-full bg-[var(--bg-primary)] text-[var(--text-secondary)]">Qty: {p.quantity}</span>
                                                {exp && <span className={`text-xs font-medium ${exp.cls}`}>⏰ {exp.label}</span>}
                                            </div>
                                        )
                                    }

                                    const totalVariantQty = variants.reduce((s, v) => s + v.quantity, 0)
                                    return (
                                        <div key={pKey}>
                                            <button onClick={() => toggleProduct(pKey)} className="w-full flex items-center gap-3 px-5 py-3 hover:bg-[var(--bg-primary)] transition-colors">
                                                <div className="w-2 h-2 rounded-full bg-amber-400 flex-shrink-0" />
                                                <span className="flex-1 text-sm font-medium text-[var(--text-primary)] capitalize text-left">{productName}</span>
                                                <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400 font-medium flex-shrink-0">
                                                    {variants.length} variants
                                                </span>
                                                <span className="text-xs text-[var(--text-muted)] hidden sm:block flex-shrink-0">Total Qty: {totalVariantQty}</span>
                                                {isOpen ? <ChevronDown size={14} className="text-[var(--text-muted)] flex-shrink-0" /> : <ChevronRight size={14} className="text-[var(--text-muted)] flex-shrink-0" />}
                                            </button>

                                            {isOpen && (
                                                <div className="bg-[var(--bg-primary)] divide-y divide-[var(--border-card)]">
                                                    <div className="grid grid-cols-5 gap-2 px-8 py-2 text-xs font-semibold text-[var(--text-muted)] uppercase tracking-wide">
                                                        <span>SKU</span><span>Price</span><span>Qty</span><span>Expiry</span><span>Value</span>
                                                    </div>
                                                    {variants.map((v, i) => {
                                                        const exp = expiryInfo(v.expiry)
                                                        return (
                                                            <div key={v.id ?? i} onClick={() => onSelect(v)} className="grid grid-cols-5 gap-2 px-8 py-3 text-sm cursor-pointer hover:bg-[var(--bg-card)] transition-colors">
                                                                <span className="text-[var(--text-muted)] truncate">{v.sku || "—"}</span>
                                                                <span className="font-semibold text-[var(--text-primary)]">₹{v.price.toLocaleString("en-IN")}</span>
                                                                <span className={`font-bold ${v.quantity === 0 ? "text-red-500" : v.quantity <= 5 ? "text-red-400" : v.quantity <= 10 ? "text-amber-500" : "text-[var(--text-primary)]"}`}>{v.quantity}</span>
                                                                <span className={`text-xs font-medium ${exp ? exp.cls : "text-[var(--text-muted)]"}`}>{exp ? `⏰ ${exp.label}` : v.expiry || "—"}</span>
                                                                <span className="text-emerald-600 font-semibold">₹{(v.price * v.quantity).toLocaleString("en-IN")}</span>
                                                            </div>
                                                        )
                                                    })}
                                                </div>
                                            )}
                                        </div>
                                    )
                                })}
                            </div>
                        )}
                    </div>
                )
            })}
        </div>
    )
}

export default function ProductGrid({ onSelect, products, loading }: {
    onSelect: (p: Product) => void
    products: Product[]
    loading: boolean
}) {
    const router = useRouter()
    const [search, setSearch] = useState("")
    const [category, setCategory] = useState("all")
    const [stockFilter, setStockFilter] = useState("all")
    const [viewMode, setViewMode] = useState<"grid" | "grouped">("grid")

    const categories = useMemo(() => {
        const cats = [...new Set(products.map(p => p.category).filter(Boolean))] as string[]
        return cats.sort()
    }, [products])

    const filtered = useMemo(() => {
        return products.filter(p => {
            const matchSearch = !search || p.name.toLowerCase().includes(search.toLowerCase()) || (p.sku || "").toLowerCase().includes(search.toLowerCase())
            const matchCategory = category === "all" || p.category === category
            const matchStock = stockFilter === "all" ? true : stockFilter === "out" ? p.quantity === 0 : p.quantity > 0 && p.quantity <= 10
            return matchSearch && matchCategory && matchStock
        })
    }, [products, search, category, stockFilter])

    const hasFilters = search || category !== "all" || stockFilter !== "all"

    if (loading) {
        return (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                {[1, 2, 3, 4, 5, 6].map(n => (
                    <div key={n} className="rounded-2xl border border-[var(--border-card)] bg-[var(--bg-card)] p-5 space-y-3">
                        <div className="skeleton h-5 w-3/4" /><div className="skeleton h-4 w-1/3" /><div className="skeleton h-12 w-full" /><div className="skeleton h-9 w-full" />
                    </div>
                ))}
            </div>
        )
    }

    if (products.length === 0) {
        return (
            <div className="flex flex-col items-center justify-center py-24 text-center">
                <div className="h-16 w-16 rounded-full bg-[var(--bg-card)] border border-[var(--border-card)] flex items-center justify-center mb-4 text-2xl shadow">📦</div>
                <h3 className="text-lg font-semibold text-[var(--text-primary)]">Koi product nahi hai</h3>
                <p className="text-sm text-[var(--text-muted)] mt-1 max-w-xs">Abhi tak koi product add nahi kiya. Pehla item add karo stock manage karne ke liye.</p>
                <Button variant="primary" onClick={() => router.push("/dashboard/add-product")} title="Product Add Karo" className="mt-5" />
            </div>
        )
    }

    return (
        <div className="space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)] pointer-events-none" />
                    <input type="text" placeholder="Product name ya SKU search karo..." value={search} onChange={e => setSearch(e.target.value)} className="w-full pl-9 pr-9 py-2 rounded-xl border border-[var(--border-input)] bg-[var(--bg-input)] text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:ring-2 focus:ring-emerald-400 outline-none transition-all text-sm" />
                    {search && <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--text-muted)] hover:text-[var(--text-primary)]"><X size={14} /></button>}
                </div>

                {categories.length > 0 && (
                    <select value={category} onChange={e => setCategory(e.target.value)} className="py-2 px-3 rounded-xl border border-[var(--border-input)] bg-[var(--bg-input)] text-[var(--text-primary)] text-sm outline-none focus:ring-2 focus:ring-emerald-400 transition-all">
                        <option value="all">Sab Categories</option>
                        {categories.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                )}

                <div className="flex gap-2">
                    {[{ key: "all", label: "Sab" }, { key: "low", label: "⚠ Low" }, { key: "out", label: "✕ Out" }].map(f => (
                        <button key={f.key} onClick={() => setStockFilter(f.key)} className={`px-3 py-2 rounded-xl text-sm font-medium border transition-all whitespace-nowrap ${stockFilter === f.key ? "bg-emerald-500 text-white border-emerald-500 shadow" : "border-[var(--border-input)] text-[var(--text-secondary)] bg-[var(--bg-input)] hover:border-emerald-400"}`}>{f.label}</button>
                    ))}
                </div>

                {/* View Mode Toggle */}
                <div className="flex gap-1 border border-[var(--border-input)] rounded-xl p-1 bg-[var(--bg-input)]">
                    <button onClick={() => setViewMode("grid")} title="Card View" className={`p-1.5 rounded-lg transition-all ${viewMode === "grid" ? "bg-emerald-500 text-white shadow" : "text-[var(--text-muted)] hover:text-[var(--text-primary)]"}`}><LayoutGrid size={16} /></button>
                    <button onClick={() => setViewMode("grouped")} title="Category Group View" className={`p-1.5 rounded-lg transition-all ${viewMode === "grouped" ? "bg-emerald-500 text-white shadow" : "text-[var(--text-muted)] hover:text-[var(--text-primary)]"}`}><List size={16} /></button>
                </div>
            </div>

            <div className="flex items-center justify-between text-xs text-[var(--text-muted)]">
                <span>{filtered.length} / {products.length} products{hasFilters ? " (filtered)" : ""}</span>
                {hasFilters && (
                    <button onClick={() => { setSearch(""); setCategory("all"); setStockFilter("all") }} className="flex items-center gap-1 text-emerald-600 hover:text-emerald-700 font-medium"><X size={12} /> Filter hatao</button>
                )}
            </div>

            {filtered.length === 0 ? (
                <div className="text-center py-16 text-[var(--text-muted)]">
                    <p className="text-3xl mb-3">🔍</p>
                    <p className="font-medium text-[var(--text-primary)]">Koi product nahi mila</p>
                    <p className="text-sm mt-1">Search ya filter change karo</p>
                </div>
            ) : viewMode === "grid" ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                    {filtered.map(p => <ProductCard key={p.id} product={p} onClick={() => onSelect(p)} />)}
                </div>
            ) : (
                <GroupedView products={filtered} onSelect={onSelect} />
            )}
        </div>
    )
}
