"use client"

import { useEffect, useState, useCallback } from "react"
import { auth } from "@/app/lib/firebase"
import { onAuthStateChanged } from "firebase/auth"
import { getGoogleDriveAccessToken } from "@/app/lib/auth.service"
import { loadProfileFromDrive, saveProfileToDrive } from "@/app/lib/profile.service"

export type ProfileState = {
  personal: {
    displayName: string
    email: string
    photoURL: string
    phone: string
    alternateEmail: string
  }
  business: {
    shopName: string
    gstNumber: string
    businessType: string
    upiId: string
    invoicePrefix: string
  }
  address: {
    address: string
    district: string
    state: string
    pincode: string
  }
  banking: {
    accountHolderName: string
    accountNumber: string
    ifscCode: string
    bankName: string
  }
  settings: {
    termsAndConditions: string
  }
  userId?: string
  updatedAt?: string
}

const defaultState: ProfileState = {
  personal: {
    displayName: "",
    email: "",
    photoURL: "",
    phone: "",
    alternateEmail: "",
  },
  business: {
    shopName: "",
    gstNumber: "",
    businessType: "retail",
    upiId: "",
    invoicePrefix: "INV",
  },
  address: {
    address: "",
    district: "",
    state: "",
    pincode: "",
  },
  banking: {
    accountHolderName: "",
    accountNumber: "",
    ifscCode: "",
    bankName: "",
  },
  settings: {
    termsAndConditions: "Goods once sold will not be taken back or exchanged.",
  },
}

export default function useProfile() {
  const [profile, setProfile] = useState<ProfileState>(defaultState)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  // Load from Drive on mount
  useEffect(() => {
    let isMounted = true

    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!isMounted) return

      if (user) {
        // Set Firebase data first
        setProfile((prev) => ({
          ...prev,
          personal: {
            ...prev.personal,
            displayName: user.displayName || "",
            email: user.email || "",
            photoURL: user.photoURL || "",
          },
        }))

        // Try to load from Drive
        try {
          const token = await getGoogleDriveAccessToken(false)
          // ✅ Yeh check zaroori hai - token string hona chahiye
          if (token && typeof token === 'string' && token.length > 0) {
            const driveData = await loadProfileFromDrive(token)
            if (driveData && isMounted) {
              setProfile(driveData)
              console.log("✅ Profile loaded from Drive")
            }
          }
        } catch (error) {
          console.error("Failed to load profile from Drive:", error)
        }
      }

      if (isMounted) setLoading(false)
    })

    return () => {
      isMounted = false
      unsubscribe()
    }
  }, [])

  // Save function
  const saveProfile = useCallback(
    async (newData: ProfileState) => {
      // ✅ Sirf silent mode - NO POPUP
      const token = await getGoogleDriveAccessToken(false)

      if (!token) {
        // ❌ Popup nahi, clear error do
        throw new Error("DRIVE_TOKEN_EXPIRED")
      }

      if (typeof token !== 'string') {
        throw new Error("Invalid token")
      }

      setSaving(true)
      try {
        await saveProfileToDrive(newData, token)
        setProfile(newData)
        console.log("✅ Profile saved")
      } catch (error) {
        console.error("Save failed:", error)
        throw error
      } finally {
        setSaving(false)
      }
    },
    []
  )


  return {
    profile,
    loading,
    saving,
    saveProfile,
    setProfile,
  }
}
