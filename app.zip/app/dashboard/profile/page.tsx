"use client"

import { useState, useEffect } from "react"
import { MdEdit, MdArrowBack } from "react-icons/md"
import { toast } from "sonner"
import ProfileForm from "./ProfileForm"
import ProfileShowcase from "./components/ProfileShowcase"
import useProfile, { ProfileState } from "./useProfile"
import Button from "@/app/components/utility/Button"
import { autoSyncProfileToDrive } from "@/app/lib/autoProfileSync.service"

export default function ProfilePage() {
    const [isEditing, setIsEditing] = useState(false)
    const { profile, loading, saveProfile } = useProfile()

    // ✅ Saare hooks yahan top pe rakho - return ke pehle!

    // Hook 1: Auto-sync jab profile change ho
    useEffect(() => {
        if (!loading && profile.business?.shopName) {
            const timer = setTimeout(() => {
                autoSyncProfileToDrive(profile)
            }, 5000)
            return () => clearTimeout(timer)
        }
    }, [profile, loading])

    // Hook 2: Auto edit mode jab profile empty ho (sirf ek baar)
    useEffect(() => {
        if (!loading && !profile.business?.shopName) {
            setIsEditing(true)
        }
    }, [loading, profile.business?.shopName])

    // Ab loading check karo - saare hooks ke baad!
    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-500"></div>
            </div>
        )
    }

    // Ye sab hooks ke baad hona chahiye
    const isProfileEmpty = !profile.business?.shopName

    const handleSave = async (data: any) => {
        try {
            await saveProfile(data)
            toast.success("Saved!")
        } catch (error: any) {
            if (error.message === "DRIVE_RECONNECT_REQUIRED" || error.message?.includes("No access token")) {
                toast.error("Please reconnect Google Drive")
                // Optional: Reconnect modal kholo
                // window.location.href = "/dashboard/settings/backup";
            } else {
                toast.error(error.message || "Save failed")
            }
        }
    }



    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between bg-[var(--bg-card)] border border-[var(--border-card)] rounded-2xl p-6 shadow-[var(--shadow-card)]">
                <div>
                    <h1 className="text-2xl font-bold text-[var(--text-primary)]">
                        {isEditing ? "Edit Profile" : "Business Profile"}
                    </h1>
                    <p className="text-sm text-[var(--text-muted)]">
                        {isEditing
                            ? "Apne business ki details update karein"
                            : "Apne business ka complete overview"}
                    </p>
                </div>

                {!isProfileEmpty && (
                    <Button variant={isEditing ? "outline" : "primary"} icon={isEditing ? <MdArrowBack /> : <MdEdit />} title={isEditing ? "Back to Profile" : "Edit Profile"} onClick={() => setIsEditing(!isEditing)} />
                )}
            </div>

            {/* Content */}
            <div className="min-h-[500px]">
                {isEditing ? (
                    <ProfileForm initialData={profile} onSave={handleSave} onCancel={() => {
                            if (!isProfileEmpty) {
                                setIsEditing(false)
                            }
                        }}
                    />
                ) : (
                    <ProfileShowcase data={{ ...profile, userId: profile.userId || '', updatedAt: profile.updatedAt || '' }} onEdit={() => setIsEditing(true)} />
                )}
            </div>
        </div>
    )
}
