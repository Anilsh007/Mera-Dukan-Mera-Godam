"use client"

import { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import {
    Search,
    X,
    Boxes,
    Package2,
    IndianRupee,
    Tag,
    Truck,
    CalendarClock,
    AlertTriangle,
    CircleOff,
    LayoutList,
} from "lucide-react"
import Button from "@/app/components/utility/Button"
import { Product } from "@/app/lib/db"
import type { CategoryGroup } from "./page"

type ProductGridProps = {
    groups: CategoryGroup[]
    loading: boolean
    onSelectGroup: (group: CategoryGroup) => void
}

function expiryInfo(expiry?: string): { label: string; cls: string } | null {
    if (!expiry) return null
    const days = Math.ceil((new Date(expiry).getTime() - Date.now()) / 86400000)
    if (days < 0) return { label: "Expired", cls: "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400" }
    if (days <= 7) return { label: `${days}d left`, cls: "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400" }
    if (days <= 30) return { label: `${days}d left`, cls: "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400" }
    return null
}

function getGroupStockState(products: Product[]) {
    const totalQty = products.reduce((sum, p) => sum + p.quantity, 0)
    const hasCritical = products.some((p) => p.quantity > 0 && p.quantity <= 5)
    const hasLow = products.some((p) => p.quantity > 5 && p.quantity <= 10)

    if (totalQty === 0) {
        return { label: "Out of Stock", cls: "bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400" }
    }

    if (hasCritical) {
        return { label: "Critical", cls: "bg-red-50 text-red-500 dark:bg-red-900/20 dark:text-red-400" }
    }

    if (hasLow) {
        return { label: "Low Stock", cls: "bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400" }
    }

    return { label: "In Stock", cls: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400" }
}

const stockFilters = [
    { key: "all", label: "Sab", icon: LayoutList, active: "bg-emerald-500 text-white border-emerald-500 shadow", iconColor: "text-sky-500", activeIcon: "text-white" },
    { key: "low", label: "Low", icon: AlertTriangle, active: "bg-amber-500 text-white border-amber-500 shadow", iconColor: "text-amber-500", activeIcon: "text-white" },
    { key: "out", label: "Out", icon: CircleOff, active: "bg-red-500 text-white border-red-500 shadow", iconColor: "text-red-500", activeIcon: "text-white" },
] as const

export default function ProductGrid({ groups, loading, onSelectGroup }: ProductGridProps) {
    const router = useRouter()
    const [search, setSearch] = useState("")
    const [category, setCategory] = useState("all")
    const [stockFilter, setStockFilter] = useState("all")

    const categories = useMemo(() => groups.map((g) => g.label).sort(), [groups])

    const filteredGroups = useMemo(() => {
        return groups.filter((group) => {
            const matchSearch = !search || group.label.toLowerCase().includes(search.toLowerCase()) || group.products.some((p) =>
                p.name.toLowerCase().includes(search.toLowerCase()) || (p.sku || "").toLowerCase().includes(search.toLowerCase())
            )

            const matchCategory = category === "all" || group.label === category
            const totalQty = group.products.reduce((sum, p) => sum + p.quantity, 0)
            const matchStock = stockFilter === "all"
                ? true
                : stockFilter === "out"
                    ? totalQty === 0
                    : group.products.some((p) => p.quantity > 0 && p.quantity <= 10)

            return matchSearch && matchCategory && matchStock
        })
    }, [groups, search, category, stockFilter])

    if (loading) {
        return <div className="rounded-3xl border border-[var(--border-card)] bg-[var(--surface-card)] p-6 text-sm text-[var(--text-secondary)] shadow-[var(--shadow-card)]">Products load ho rahe hain...</div>
    }

    if (groups.length === 0) {
        return (
            <div className="rounded-3xl border border-[var(--border-card)] bg-[var(--surface-card)] p-8 text-center shadow-[var(--shadow-card)] space-y-4">
                <p className="text-lg font-semibold">Abhi tak koi product add nahi kiya.</p>
                <p className="text-sm text-[var(--text-secondary)]">Pehla item add karo stock manage karne ke liye.</p>
                <div className="flex justify-center">
                    <Button title="Add Product" onClick={() => router.push("/dashboard/add-product")} />
                </div>
            </div>
        )
    }

    return (
        <>
            <div className="p-4 sm:p-6 bg-[var(--bg-card)] border border-[var(--border-card)] rounded-2xl shadow-[var(--shadow-card)]">
                <div className="flex flex-col gap-3 sm:flex-row">
                    <div className="relative flex-1">
                        <Search
                            size={16}
                            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-emerald-500"
                        />
                        <input
                            type="text"
                            placeholder="Product name ya SKU search karo..."
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                            className="w-full rounded-xl border border-[var(--border-input)] bg-[var(--bg-input)] py-2 pl-9 pr-9 text-sm text-[var(--text-primary)] placeholder-[var(--text-muted)] outline-none transition-all focus:ring-2 focus:ring-emerald-400"
                        />
                        {search && (
                            <button
                                onClick={() => setSearch("")}
                                className="absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer text-rose-500 hover:text-rose-600"
                            >
                                <X size={14} />
                            </button>
                        )}
                    </div>

                    {categories.length > 0 && (
                        <select
                            value={category}
                            onChange={(e) => setCategory(e.target.value)}
                            className="rounded-xl border border-[var(--border-input)] bg-[var(--bg-input)] px-3 py-2 text-sm text-[var(--text-primary)] outline-none transition-all focus:ring-2 focus:ring-emerald-400"
                        >
                            <option value="all">Sab Categories</option>
                            {categories.map((c) => (
                                <option key={c} value={c}>{c}</option>
                            ))}
                        </select>
                    )}

                    <div className="flex gap-2">
                        {stockFilters.map((f) => {
                            const Icon = f.icon
                            const active = stockFilter === f.key
                            return (
                                <button
                                    key={f.key}
                                    onClick={() => setStockFilter(f.key)}
                                    className={`cursor-pointer whitespace-nowrap rounded-xl border px-3 py-2 text-sm font-medium transition-all ${active
                                            ? f.active
                                            : "border-[var(--border-input)] bg-[var(--bg-input)] text-[var(--text-secondary)] hover:border-emerald-400"
                                        }`}
                                >
                                    <span className="inline-flex items-center gap-1.5">
                                        <Icon size={14} className={active ? f.activeIcon : f.iconColor} />
                                        {f.label}
                                    </span>
                                </button>
                            )
                        })}
                    </div>
                </div>
            </div>

            {filteredGroups.length === 0 ? (
                <div className="rounded-3xl border border-[var(--border-card)] bg-[var(--surface-card)] p-8 text-center shadow-[var(--shadow-card)]">
                    <p className="text-lg font-semibold">Koi product nahi mila</p>
                    <p className="text-sm text-[var(--text-secondary)]">Search ya filter change karo.</p>
                </div>
            ) : (
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    {filteredGroups.map((group) => {
                        const stockState = getGroupStockState(group.products)
                        const previewProducts = group.products.slice(0, 3)

                        return (
                            <button
                                key={group.key}
                                onClick={() => onSelectGroup(group)}
                                className="cursor-pointer rounded-3xl border border-[var(--border-card)] bg-[var(--surface-card)] p-5 text-left shadow-[var(--shadow-card)] transition hover:-translate-y-0.5"
                            >
                                <div className="flex items-start justify-between gap-3">
                                    <div className="min-w-0">
                                        <div className="flex items-center gap-2">
                                            <div className="rounded-2xl bg-emerald-50 p-2 text-emerald-600 dark:bg-emerald-900/20 dark:text-emerald-400">
                                                <Boxes className="h-4 w-4" />
                                            </div>
                                            <div>
                                                <h3 className="truncate text-lg font-semibold capitalize">{group.label}</h3>
                                                <p className="text-sm text-[var(--text-secondary)]">{group.products.length} products</p>
                                            </div>
                                        </div>
                                    </div>
                                    <span className={`shrink-0 rounded-full px-3 py-1 text-xs font-medium ${stockState.cls}`}>
                                        {stockState.label}
                                    </span>
                                </div>

                                <div className="mt-4 grid grid-cols-3 gap-3">
                                    <div className="rounded-2xl bg-[var(--surface-primary)] p-3">
                                        <div className="mb-1 flex items-center gap-1 text-sky-500">
                                            <Package2 className="h-3.5 w-3.5" />
                                            <span className="text-xs text-[var(--text-secondary)]">Items</span>
                                        </div>
                                        <p className="text-sm font-semibold">{group.products.length}</p>
                                    </div>
                                    <div className="rounded-2xl bg-[var(--surface-primary)] p-3">
                                        <div className="mb-1 flex items-center gap-1 text-violet-500">
                                            <Tag className="h-3.5 w-3.5" />
                                            <span className="text-xs text-[var(--text-secondary)]">Qty</span>
                                        </div>
                                        <p className="text-sm font-semibold">{group.totalQty}</p>
                                    </div>
                                    <div className="rounded-2xl bg-[var(--surface-primary)] p-3">
                                        <div className="mb-1 flex items-center gap-1 text-emerald-500">
                                            <IndianRupee className="h-3.5 w-3.5" />
                                            <span className="text-xs text-[var(--text-secondary)]">Value</span>
                                        </div>
                                        <p className="text-sm font-semibold">₹{group.totalValue.toLocaleString("en-IN")}</p>
                                    </div>
                                </div>

                                <div className="mt-4 space-y-2">
                                    {previewProducts.map((product) => {
                                        const expInfo = expiryInfo(product.expiry)
                                        return (
                                            <div
                                                key={product.id}
                                                className="rounded-2xl border border-[var(--border-card)] bg-[var(--surface-primary)] px-3 py-3 shadow-[var(--shadow-card)]"
                                            >
                                                <div className="flex items-start justify-between gap-3">
                                                    <div className="min-w-0">
                                                        <p className="truncate font-semibold capitalize">{product.name}</p>
                                                        <p className="truncate text-xs text-[var(--text-secondary)]">
                                                            {product.category || "Category nahi"}
                                                            {product.sku ? ` · ${product.sku}` : ""}
                                                        </p>
                                                    </div>
                                                    <p className="text-sm font-semibold">Qty {product.quantity}</p>
                                                </div>

                                                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                                                    <div>
                                                        <p className="text-[var(--text-secondary)]">Price</p>
                                                        <p className="font-medium">₹{product.price.toLocaleString("en-IN")}</p>
                                                    </div>
                                                    <div>
                                                        <p className="text-[var(--text-secondary)]">Value</p>
                                                        <p className="font-medium">₹{(product.price * product.quantity).toLocaleString("en-IN")}</p>
                                                    </div>
                                                </div>

                                                {(product.expiry || product.supplier) && (
                                                    <div className="mt-3 flex flex-wrap gap-2 text-xs text-[var(--text-secondary)]">
                                                        {product.supplier && (
                                                            <span className="inline-flex items-center gap-1 rounded-full bg-sky-50 px-2.5 py-1 text-sky-700 dark:bg-sky-900/20 dark:text-sky-300">
                                                                <Truck className="h-3 w-3" />
                                                                {product.supplier}
                                                            </span>
                                                        )}
                                                        {(expInfo || product.expiry) && (
                                                            <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 ${expInfo?.cls || "bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-300"}`}>
                                                                <CalendarClock className="h-3 w-3" />
                                                                {expInfo ? expInfo.label : `Exp: ${product.expiry}`}
                                                            </span>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        )
                                    })}

                                    {group.products.length > 3 && (
                                        <p className="pt-1 text-xs font-medium text-[var(--text-secondary)]">
                                            +{group.products.length - 3} aur products dekhne ke liye open karo
                                        </p>
                                    )}
                                </div>
                            </button>
                        )
                    })}
                </div>
            )}
        </>
    )
}