"use client"

import { useEffect, useMemo, useState } from "react"
import {
    ArrowLeft,
    CalendarClock,
    IndianRupee,
    Package2,
    TrendingDown,
    TrendingUp,
    Truck,
    ScanBarcode,
    LayoutGrid,
} from "lucide-react"
import { Product } from "@/app/lib/db"
import { getProductLogs } from "@/app/dashboard/add-product/product.service"
import Button from "@/app/components/utility/Button"
import StockHistoryTabs from "./StockHistoryTabs"
import StockInModal from "./StockInModal"
import StockOutModal from "./StockOutModal"

type CategoryGroup = {
    key: string
    label: string
    products: Product[]
    totalQty: number
    totalValue: number
}

type Log = {
    id: string
    date: string
    quantityAdded: number
    type?: "in" | "out"
    reason?: string
    price: number
    expiry?: string
    note?: string
    productId?: number
}

export default function ProductDetails({
    group,
    activeProductId,
    onChangeProduct,
    onBack,
}: {
    group: CategoryGroup
    activeProductId: number | null
    onChangeProduct: (productId: number | null) => void
    onBack?: () => void
}) {
    const [logs, setLogs] = useState<Log[]>([])
    const [loading, setLoading] = useState(true)
    const [modal, setModal] = useState<"in" | "out" | null>(null)

    const activeProduct = useMemo(() => {
        return group.products.find((p) => p.id === activeProductId) ?? group.products[0]
    }, [group.products, activeProductId])

    useEffect(() => {
        if (!activeProduct?.id) return
        setLoading(true)
        getProductLogs(activeProduct.id).then((data) => {
            setLogs(data.map((log) => ({
                ...log,
                id: String(log.id),
            })))
            setLoading(false)
        })
    }, [activeProduct?.id])

    if (!activeProduct) {
        return (
            <div className="rounded-3xl border border-[var(--border-card)] bg-[var(--surface-card)] p-6 shadow-[var(--shadow-card)]">
                <p>No product found.</p>
            </div>
        )
    }

    const isCritical = activeProduct.quantity <= 5
    const isLow = activeProduct.quantity > 5 && activeProduct.quantity <= 10
    const isOut = activeProduct.quantity === 0

    const qtyColor = isOut
        ? "text-red-500"
        : isCritical
            ? "text-red-400"
            : isLow
                ? "text-amber-500"
                : "text-emerald-600"

    const totalIn = logs.filter((l) => l.quantityAdded > 0).reduce((s, l) => s + l.quantityAdded, 0)
    const totalOut = logs.filter((l) => l.quantityAdded < 0).reduce((s, l) => s + Math.abs(l.quantityAdded), 0)

    return (
        <div className="space-y-4">
            <div className="p-4 sm:p-6 bg-[var(--bg-card)] border border-[var(--border-card)] rounded-2xl shadow-[var(--shadow-card)] space-y-4">
                <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                        <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-[var(--surface-primary)] px-3 py-1 text-xs text-[var(--text-secondary)]">
                            <LayoutGrid className="h-3.5 w-3.5" />
                            Category overview
                        </div>
                        <h2 className="text-2xl font-bold capitalize">{group.label}</h2>
                        <p className="mt-1 text-sm text-[var(--text-secondary)]">
                            {group.products.length} products · Total Qty {group.totalQty} · Total Value ₹{group.totalValue.toLocaleString("en-IN")}
                        </p>
                    </div>

                    {onBack && (
                        <button
                            onClick={onBack}
                            className="inline-flex cursor-pointer items-center gap-2 self-start rounded-2xl border border-[var(--border-card)] bg-[var(--surface-primary)] px-4 py-2 text-sm shadow-[var(--shadow-card)]"
                        >
                            <ArrowLeft className="h-4 w-4" />
                            Back
                        </button>
                    )}
                </div>

                <div className="flex gap-2 overflow-x-auto pb-1">
                    {group.products.map((product) => {
                        const isActive = product.id === activeProduct.id
                        return (
                            <button
                                key={product.id}
                                onClick={() => onChangeProduct(product.id ?? null)}
                                className={`cursor-pointer whitespace-nowrap rounded-full border border-[var(--border-card)] px-4 py-2 text-sm shadow-[var(--shadow-card)] transition ${isActive
                                        ? "bg-[var(--btn-primary)] text-white"
                                        : "bg-[var(--surface-primary)] text-[var(--text-primary)]"
                                    }`}
                            >
                                <span className="capitalize">{product.name}</span>
                                <span className="ml-2 text-xs opacity-80">Qty {product.quantity}</span>
                            </button>
                        )
                    })}
                </div>
            </div>

            <div className="p-4 sm:p-6 bg-[var(--bg-card)] border border-[var(--border-card)] rounded-2xl shadow-[var(--shadow-card)] space-y-4">
                <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                        <h3 className="text-xl font-semibold capitalize">{activeProduct.name}</h3>
                        <p className="text-sm text-[var(--text-secondary)]">
                            {activeProduct.category || "Category nahi"}
                            {activeProduct.sku ? ` · ${activeProduct.sku}` : ""}
                        </p>
                    </div>

                    <div className="flex gap-2">
                        <Button title="Stock In" onClick={() => setModal("in")} className="flex-1" />
                        <Button title="Stock Out" onClick={() => setModal("out")} disabled={isOut} className="flex-1" />
                    </div>
                </div>

                <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                    {[
                        { label: "Stock", value: activeProduct.quantity, cls: qtyColor, icon: Package2 },
                        { label: "Price", value: `₹${activeProduct.price.toLocaleString("en-IN")}`, cls: "", icon: IndianRupee },
                        { label: "Total Value", value: `₹${(activeProduct.price * activeProduct.quantity).toLocaleString("en-IN")}`, cls: "text-emerald-600 dark:text-emerald-400", icon: IndianRupee },
                        { label: "Total In", value: totalIn, cls: "text-emerald-600", icon: TrendingUp },
                        { label: "Total Out", value: totalOut, cls: "text-red-500", icon: TrendingDown },
                        { label: "Expiry", value: activeProduct.expiry || "—", cls: "text-amber-500", icon: CalendarClock },
                    ].map((s) => {
                        const Icon = s.icon
                        return (
                            <div key={s.label} className="rounded-2xl bg-[var(--surface-primary)] p-4">
                                <div className="mb-2 flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                                    <Icon className="h-4 w-4" />
                                    <span>{s.label}</span>
                                </div>
                                <p className={`text-lg font-semibold ${s.cls}`}>{s.value}</p>
                            </div>
                        )
                    })}
                </div>

                <div className="rounded-2xl bg-[var(--surface-primary)] p-4 space-y-3">
                    <h4 className="font-semibold">Product Info</h4>

                    <div className="grid gap-2 sm:grid-cols-2">
                        <div className="rounded-2xl border border-[var(--border-card)] bg-[var(--surface-card)] p-3 text-sm shadow-[var(--shadow-card)]">
                            <div className="mb-1 flex items-center gap-2 text-[var(--text-secondary)]">
                                <Truck className="h-4 w-4" />
                                <span>Supplier</span>
                            </div>
                            <p className="font-medium">{activeProduct.supplier || "—"}</p>
                        </div>

                        <div className="rounded-2xl border border-[var(--border-card)] bg-[var(--surface-card)] p-3 text-sm shadow-[var(--shadow-card)]">
                            <div className="mb-1 flex items-center gap-2 text-[var(--text-secondary)]">
                                <ScanBarcode className="h-4 w-4" />
                                <span>SKU</span>
                            </div>
                            <p className="font-medium">{activeProduct.sku || "—"}</p>
                        </div>

                        <div className="rounded-2xl border border-[var(--border-card)] bg-[var(--surface-card)] p-3 text-sm shadow-[var(--shadow-card)] sm:col-span-2">
                            <div className="mb-1 flex items-center gap-2 text-[var(--text-secondary)]">
                                <CalendarClock className="h-4 w-4" />
                                <span>Added On</span>
                            </div>
                            <p className="font-medium">
                                {new Date(activeProduct.createdAt).toLocaleDateString("en-IN", {
                                    day: "2-digit",
                                    month: "short",
                                    year: "numeric",
                                })}
                            </p>
                        </div>
                    </div>

                    {activeProduct.note && (
                        <div className="rounded-2xl border border-[var(--border-card)] bg-[var(--surface-card)] p-3 text-sm shadow-[var(--shadow-card)]">
                            <span className="text-[var(--text-secondary)]">Note: </span>
                            <span className="font-medium">{activeProduct.note}</span>
                        </div>
                    )}
                </div>
            </div>

            <div className="p-4 sm:p-6 bg-[var(--bg-card)] border border-[var(--border-card)] rounded-2xl shadow-[var(--shadow-card)]">
                {loading ? (
                    <p className="text-sm text-[var(--text-secondary)]">History load ho rahi hai...</p>
                ) : (
                    <StockHistoryTabs logs={logs} products={[activeProduct]} />
                )}
            </div>

            {modal && (
                <div
                    className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
                    onClick={() => setModal(null)}
                >
                    <div className="max-h-[90vh] w-full max-w-4xl overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                        {modal === "in" ? (
                            <StockInModal product={activeProduct} onClose={() => setModal(null)} />
                        ) : (
                            <StockOutModal product={activeProduct} onClose={() => setModal(null)} />
                        )}
                    </div>
                </div>
            )}
        </div>
    )
}