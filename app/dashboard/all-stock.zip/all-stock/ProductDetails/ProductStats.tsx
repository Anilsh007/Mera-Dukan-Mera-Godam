"use client"

import { CalendarClock, IndianRupee, Package2, TrendingDown, TrendingUp, Truck, ScanBarcode, AlertTriangle, } from "lucide-react"
import Button from "@/app/components/utility/Button"
import { Product } from "@/app/lib/db"

type Log = {
    id: string
    quantityAdded: number
    price: number
    expiry?: string
}

export default function ProductStats({ product, logs, setModal, }: {
    product: Product
    logs: Log[]
    setModal: (type: "in" | "out" | null) => void
}) {
    const isOut = product.quantity === 0
    const isCritical = product.quantity > 0 && product.quantity <= 5
    const isLow = product.quantity > 5 && product.quantity <= 10

    const qtyColor = isOut ? "text-[var(--out-stock-text)]" : isCritical ? "text-[var(--critical-stock-text)]" : isLow ? "text-[var(--low-stock-text)]" : "text-[var(--all-stock-text)]"

    const totalIn = logs
        .filter((l) => l.quantityAdded > 0)
        .reduce((sum, l) => sum + l.quantityAdded, 0)

    const totalOut = logs
        .filter((l) => l.quantityAdded < 0)
        .reduce((sum, l) => sum + Math.abs(l.quantityAdded), 0)

    const latestPrice =
        logs.find((l) => Number(l.price) > 0)?.price ||
        (product as any).price ||
        0

    const inventoryValue =
        Number(product.quantity || 0) * Number(latestPrice || 0)

    const latestExpiry =
        logs
            .filter((l) => l.expiry)
            .map((l) => l.expiry)
            .sort()[0] || (product as any).expiry

    const stockStatus = isOut
        ? {
            label: "Out of stock",
            tone: "bg-[var(--out-stock)] text-[var(--out-stock-text)] border-[var(--out-stock-border)]",
            icon: AlertTriangle,
        }
        : isCritical
            ? {
                label: "Critical stock",
                tone: "bg-[var(--critical-stock)] text-[var(--critical-stock-text)] border-[var(--critical-stock-border)]",
                icon: AlertTriangle,
            }
            : isLow
                ? {
                    label: "Low stock",
                    tone: "bg-[var(--low-stock)] text-[var(--low-stock-text)] border-[var(--low-stock-border)]",
                    icon: AlertTriangle,
                }
                : {
                    label: "Healthy stock",
                    tone: "bg-[var(--all-stock)] text-[var(--all-stock-text)] border-[var(--all-stock-border)]",
                    icon: Package2,
                }

    const StatusIcon = stockStatus.icon

    const cardClass = "rounded-xl sm:rounded-2xl border border-[var(--border-card)] bg-[var(--surface-primary)] p-3 sm:p-4 shadow-[var(--shadow-card)]"

    const stats = [
        {
            label: "Total In",
            value: totalIn,
            icon: TrendingUp,
            tone: "text-[var(--all-stock-text)] bg-[var(--all-stock)]",
        },
        {
            label: "Total Out",
            value: totalOut,
            icon: TrendingDown,
            tone: "text-[var(--out-stock-text)] bg-[var(--out-stock)]",
        },
        {
            label: "Inventory Value",
            value: inventoryValue
                ? `₹${inventoryValue.toLocaleString("en-IN")}`
                : "—",
            icon: IndianRupee,
            tone: "text-[var(--all-stock-text)] bg-[var(--all-stock)]",
        },
        {
            label: "Expiry",
            value: latestExpiry || "—",
            icon: CalendarClock,
            tone: "text-[var(--all-stock-text)] bg-[var(--all-stock)]",
        },
    ]

    return (
        <div className="space-y-4 sm:space-y-5">
            <div className="overflow-hidden rounded-2xl sm:rounded-[28px]">

                {/* Header */}
                <div className="border-b border-[var(--border-card)] p-4 sm:p-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between border border-[var(--border-card)] bg-[var(--bg-card)] shadow-[var(--shadow-card)]">

                    <div className="min-w-0">
                        <h3 className="text-lg sm:text-xl font-bold truncate">
                            {product.name}
                        </h3>

                        <div className={`mt-2 inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-semibold ${stockStatus.tone}`} >
                            <StatusIcon size={14} />
                            {stockStatus.label}
                        </div>
                    </div>

                    {/* Buttons */}
                    <div className="flex flex-wrap gap-2 sm:gap-3 w-full md:w-auto">
                        <Button onClick={() => setModal("in")} title="Add Stock" icon={<TrendingUp size={16} />} variant="success" className="w-full sm:w-auto text-xs sm:text-sm" />
                        <Button onClick={() => setModal("out")} title="Sale Stock" icon={<TrendingDown size={16} />} variant="danger" className="w-full sm:w-auto text-xs sm:text-sm" />
                    </div>
                </div>

                {/* Responsive Grid */}
                <div className="grid gap-3 p-4 sm:p-5 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 border-t border-zinc-400/40 bg-[var(--bg-card)]">

                    {/* Info Cards */}
                    <InfoMiniCard icon={ScanBarcode} label="SKU" value={product.sku || "—"} className={cardClass} />
                    <InfoMiniCard icon={Truck} label="Supplier" value={(product as any).supplier || "—"} className={cardClass} />

                    {/* Stats Cards */}
                    {stats.map((stat) => (
                        <div key={stat.label} className="rounded-xl sm:rounded-2xl border border-[var(--border-card)] bg-[var(--surface-primary)] p-3 sm:p-4 shadow-[var(--shadow-card)]" >
                            <div className="flex items-center justify-between">
                                <div className="min-w-0">
                                    <p className="text-xs sm:text-sm text-[var(--text-secondary)]">
                                        {stat.label}
                                    </p>
                                    <p className="mt-1 text-base sm:text-xl font-bold truncate">
                                        {typeof stat.value === "number"
                                            ? stat.value.toLocaleString("en-IN")
                                            : stat.value}
                                    </p>
                                </div>

                                <div className={`flex h-9 w-9 sm:h-11 sm:w-11 items-center justify-center rounded-xl ${stat.tone}`} >
                                    <stat.icon size={16} />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    )
}

function InfoMiniCard({
    icon: Icon,
    label,
    value,
    className,
}: {
    icon: any
    label: string
    value: string
    className?: string
}) {
    return (
        <div className={className}>
            <div className="flex items-center justify-between">
                <div className="min-w-0">
                    <p className="text-xs sm:text-sm text-[var(--text-secondary)]">
                        {label}
                    </p>
                    <p className="mt-1 text-base sm:text-xl font-bold truncate">
                        {value || "—"}
                    </p>
                </div>

                <div className="flex h-9 w-9 sm:h-11 sm:w-11 items-center justify-center rounded-xl bg-[var(--btn-primary)]/10 text-[var(--btn-primary)]">
                    <Icon size={16} />
                </div>
            </div>
        </div>
    )
}