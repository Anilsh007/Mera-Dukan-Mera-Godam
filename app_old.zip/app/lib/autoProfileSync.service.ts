import { toast } from "sonner";
import { getGoogleDriveAccessToken } from "./auth.service";
import { saveProfileToDrive } from "./profile.service";

let isSyncing = false;

export async function autoSyncProfileToDrive(profileData: any, showToast = false) {
  if (isSyncing) return;

  try {
    isSyncing = true;

    const isConnected = localStorage.getItem("drive_connected");
    if (!isConnected || !navigator.onLine) {
      if (showToast) toast.error("Drive not connected");
      return;
    }

    const token = await getGoogleDriveAccessToken(false);
    if (!token) {
      if (showToast) toast.error("Session expired. Please reconnect.");
      return;
    }

    if (showToast) toast.info("Syncing profile...");
    await saveProfileToDrive(profileData, token);
    if (showToast) toast.success("Profile saved to Drive!");

  } catch (err: any) {
    console.error("❌ Profile sync failed:", err);
    if (showToast) toast.error(`Save failed: ${err.message}`);
    throw err; // Re-throw so caller knows
  } finally {
    isSyncing = false;
  }
}
